# Health Net

HealthNet is an AI-powered platform designed to make healthcare accessible, reliable, and efficient. Our mission is to leverage technology to provide users with real-time, data-driven medical assistance and resources, empowering them to manage their health effectively.

## Implemented Features
- Medicine check up caht bot
- First Aid Help
## Upcoming Features
- Mental health help
- Emergency contact to nearest hospital
- Skin disease prediction by ML
- Local Pharmacy contact
- Workout plans for physical health
- Menstrual cycle tracker
